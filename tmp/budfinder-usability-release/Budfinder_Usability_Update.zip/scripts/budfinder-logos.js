(() => {
  'use strict';

  // Public pages are served from the site root. Keep each candidate unique so a
  // missing logo produces one inexpensive miss instead of retrying equivalent
  // relative paths from the same page.
  const LOGO_BASE_PATH = '/images/logos/';
  const LOGO_FILE_ALIASES = new Map([
    ['best_friends_centrum.png', 'best_friends_oost.png'],
    ['bulldog_energy.png', 'bulldog_rockshop.png'],
    ['bulldog_no_90.png', 'bulldog_rockshop.png'],
    ['bulldog_palace.png', 'bulldog_rockshop.png'],
    ['marbella_specical_farmers.png', 'marbella_special_farmers.png']
  ]);
  const FAILED_LOGO_URLS = new Set();

  function absoluteLogoUrl(value) {
    try {
      return new URL(String(value || ''), window.location.href).href;
    } catch (_) {
      return String(value || '');
    }
  }

  function logoSlug(value) {
    return String(value || '')
      .trim()
      .toLowerCase()
      .replace(/^cs-/, '')
      .replace(/&/g, ' and ')
      .replace(/[^a-z0-9]+/g, '_')
      .replace(/^_+|_+$/g, '');
  }

  function logoInitials(value, fallback = 'CS') {
    const parts = String(value || '')
      .trim()
      .split(/\s+/)
      .filter(Boolean);
    return (parts.slice(0, 2).map(part => part.charAt(0).toUpperCase()).join('') || fallback).slice(0, 2);
  }

  function monogramDataUrl(shopName, shopKey, filename) {
    const label = shopName || logoSlug(shopKey).replace(/_/g, ' ') || filename || 'Coffeeshop';
    const monogram = logoInitials(label);
    const svg =
      `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 96 96">` +
        `<rect width="96" height="96" rx="22" fill="#ffffff"/>` +
        `<circle cx="48" cy="48" r="35" fill="#183f32"/>` +
        `<text x="48" y="58" text-anchor="middle" font-family="Arial,sans-serif" font-size="30" font-weight="800" fill="#ffffff">${monogram}</text>` +
      `</svg>`;
    return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svg)}`;
  }

  function addLogoPath(out, seen, rawValue) {
    const raw = String(rawValue || '').trim();
    if (!raw) return;
    if (/^(?:data:|https?:\/\/)/i.test(raw)) {
      if (!seen.has(raw) && !FAILED_LOGO_URLS.has(absoluteLogoUrl(raw))) {
        seen.add(raw);
        out.push(raw);
      }
      return;
    }
    const clean = raw.replace(/^\.?\//, '').replace(/^\/+/, '');
    if (!clean) return;
    const parts = clean.split('/').filter(Boolean);
    const basename = parts[parts.length - 1] || clean;
    const paths = clean.includes('/') && !/^images\/logos\//i.test(clean)
      ? [`/${clean}`, `${LOGO_BASE_PATH}${encodeURIComponent(basename)}`]
      : [`${LOGO_BASE_PATH}${encodeURIComponent(basename)}`];
    paths.forEach(path => {
      if (seen.has(path) || FAILED_LOGO_URLS.has(absoluteLogoUrl(path))) return;
      seen.add(path);
      out.push(path);
    });
  }

  function candidates(options = {}) {
    const settings = typeof options === 'string' ? { filename: options } : (options || {});
    const filename = String(settings.filename || '').trim();
    const shopKey = String(settings.shopKey || '').trim();
    const shopName = String(settings.shopName || '').trim();
    const out = [];
    const seen = new Set();
    const filenames = [];

    if (filename) {
      const basename = String(filename).split('/').filter(Boolean).at(-1) || '';
      const alias = LOGO_FILE_ALIASES.get(basename.toLowerCase());
      if (alias) filenames.push(alias);
      filenames.push(filename);
    } else {
      [logoSlug(shopKey), logoSlug(shopName)]
        .filter(Boolean)
        .forEach(slug => {
          filenames.push(`${slug}.png`);
        });
    }

    filenames.forEach(candidate => {
      addLogoPath(out, seen, candidate);
    });

    if (settings.includeMonogram !== false) {
      const fallback = monogramDataUrl(shopName, shopKey, filename);
      if (!seen.has(fallback)) out.push(fallback);
    }
    return out;
  }

  function advanceImage(img) {
    if (!img) return false;
    FAILED_LOGO_URLS.add(absoluteLogoUrl(img.currentSrc || img.src));
    const all = String(img.getAttribute('data-candidates') || '').split('|').filter(Boolean);
    let nextIndex = Number(img.getAttribute('data-idx') || 0) + 1;
    while (all[nextIndex] && FAILED_LOGO_URLS.has(absoluteLogoUrl(all[nextIndex]))) {
      nextIndex += 1;
    }
    if (!all[nextIndex]) return false;
    img.setAttribute('data-idx', String(nextIndex));
    img.src = all[nextIndex];
    return true;
  }

  window.BudfinderLogos = Object.freeze({
    advanceImage,
    candidates,
    initials: logoInitials,
    slug: logoSlug
  });
})();
